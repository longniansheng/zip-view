export default function sum(a, b, c) {
  return a + b + c;
}
